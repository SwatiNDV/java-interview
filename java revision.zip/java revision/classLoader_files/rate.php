PDRTJS_992345_post_113.avg_rating = 4.5;
PDRTJS_992345_post_113.votes = 14;		
PDRTJS_settings_992345_post_113= {"type":"stars","star_color":"yellow","size":"sml","custom_star":"","font_align":"left","font_position":"top","font_family":"","font_size":"","font_line_height":"16px","font_bold":"normal","font_italic":"normal","text_votes":"Votes","text_rate_this":"Rate This","text_1_star":"Very Poor","text_2_star":"Poor","text_3_star":"Average","text_4_star":"Good","text_5_star":"Excellent","text_thank_you":"Thank You","text_rate_up":"Rate Up","text_rate_down":"Rate Down","font_color":""};
PDRTJS_992345_post_113.init();		
PDRTJS_992345_post_113.token='87c435020f20856b55dbe23b910285dd';
/*992345,_post_113,wp-post-113,3753611193,4.5-14*/